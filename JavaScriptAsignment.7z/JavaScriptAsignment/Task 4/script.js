/* ------------------------------ TASK 4 -----------------------------------
Parašykite JS kodą, vartotjui atėjus į tinkaį kreipsis į cars.json failą
ir iš atvaizduos visus automobilių gamintojus ir pagamintus modelius. 
Kiekvienas gamintojas turės savo atvaizdavimo "kortelę", kurioje bus 
nurodomas gamintojas ir jo pagaminti modeliai.


Pastaba: Informacija apie automobilį (brand) (jo kortelė) bei turi turėti 
bent minimalų stilių;
-------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function() {
    fetch("cars.json")
    .then(response => response.json())
    .then(cars => displayCars(cars))
});

function displayCars(cars) {
    const outputElement = document.getElementById('output');
    outputElement.innerHTML = ''; // Valome ankstesnį turinį

    cars.forEach(car => {
        const carElement = document.createElement('div');
        carElement.classList.add('car-card');

        const brandElement = document.createElement('h2');
        brandElement.textContent = car.brand;
        carElement.appendChild(brandElement);

        const modelsList = document.createElement('ul');
        car.models.forEach(model => {
            const modelItem = document.createElement('li');
            modelItem.textContent = model;
            modelsList.appendChild(modelItem);
        });
        carElement.appendChild(modelsList);

        outputElement.appendChild(carElement);
    });
}



