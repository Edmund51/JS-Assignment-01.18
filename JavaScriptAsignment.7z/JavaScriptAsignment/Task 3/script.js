/* ------------------------------ TASK 3 -----------------------------------
Parašykite JS kodą, kuris leis vartotojui paspaudus ant mygtuko "Show users"
pamatyti vartotojus iš Github API (endpoint'as pateiktas žemiau).

Paspaudus mygtuką "Show users":
1. Pateikiamas informacijos atvaizdavimas <div id="output"></div> bloke
1.1. Informacija, kuri pateikiama: "login" ir "avatar_url" reikšmės (kortelėje)
2. Žinutė "Press "Show Users" button to see users" turi išnykti;
"
Pastaba: Informacija apie user'į (jo kortelė) bei turi turėti bent minimalų stilių;
-------------------------------------------------------------------------- */



document.addEventListener('DOMContentLoaded', function() {
    const button = document.getElementById('btn');
    const output = document.getElementById('output');
    const message = document.getElementById('message');
    const ENDPOINT = 'https://api.github.com/users';

    button.addEventListener('click', function() {
        fetch(ENDPOINT)
            .then(response => response.json())
            .then(users => {
                message.style.display = 'none'; 
                output.innerHTML = users.map(user => `
                    <div class="user-card">
                        <img src="${user.avatar_url}" alt="${user.login}" width="50" height="50">
                        <p>${user.login}</p>
                    </div>
                `).join('');
            })
            .catch(error => {
                console.error('Error fetching data: ', error);
                output.innerHTML = '<p>Failed to load users.</p>';
            });
    });
});
