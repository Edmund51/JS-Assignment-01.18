/* ------------------------------ TASK 9 ---------------------------------------------------------------
Sukurkite klasę "Car" (naudokite ES6), kuri sukuria objektus su 3 savybėm ir 1 metodu:

Savybės:
make, model
Privati savybė:
horsepower
Metodas: 
isPowerful() - jeigu automobilio horsepower bus didesnis nei 300, tada grąžins true, kitu atveju false 
------------------------------------------------------------------------------------------------------ */


// Test


class Car {
    constructor(make, model, horsepower) {
        this.make = make;
        this.model = model;
        this.#horsepower = horsepower;
    }

    #horsepower;

    isPowerful() {
        return this.#horsepower > 300;
    }
}
const car1 = new Car('Toyota', 'Corolla', 150);
const car2 = new Car('Dodge', 'Charger', 370);
const car3 = new Car('BMW', 'X7', 550);
const car4 = new Car('Opel', 'Corsa', 100);



console.log(car1.isPowerful()); 
console.log(car2.isPowerful()); 

console.log(car3.isPowerful()); 
console.log(car4.isPowerful()); 