/* ------------------------------ TASK 2 ----------------------------
Parašykite JS kodą, kuris skaičiuos kiek kartų buvo paspaustas mygtukas
su tekstu "CLICK ME". Paspaudimų rezultatas turi būti matomas dešinėje
pusėje esančiame "state" skaičiavimo bloke (<div id="btn__state">0</div>)
------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function() {
    // Select the button element
    let button = document.getElementById('btn__element');

    // Initialize the counter
    let counter = 0;

    // Add click event listener to the button
    button.addEventListener('click', function() {
        // Increment the counter
        counter++;

        // Update the counter display
        document.getElementById('btn__state').textContent = counter;
    });
});